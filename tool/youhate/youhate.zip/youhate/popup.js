const defaultSettings = {
    secondary: true,
    below: true,
    sections: true,
    footer: true,
    start: true,
    end: true
};

const ids = [
    "secondary",
    "below",
    "sections",
    "footer",
    "start",
    "end"
];


// 저장된 설정 불러오기
chrome.storage.local.get(defaultSettings, function(settings) {

    ids.forEach(function(id) {
        document.getElementById(id).checked = settings[id];
    });

});


// 체크박스 변경
ids.forEach(function(id) {

    document.getElementById(id).addEventListener("change", function() {

        const value = this.checked;

        chrome.storage.local.set({
            [id]: value
        });

        const message = document.getElementById("message");

        message.style.display = "block";

        clearTimeout(window.messageTimer);

        window.messageTimer = setTimeout(function() {
            message.style.display = "none";
        }, 2500);

    });

});