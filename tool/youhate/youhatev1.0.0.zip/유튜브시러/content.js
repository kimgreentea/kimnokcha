const defaultSettings = {
    secondary: true,
    below: true,
    sections: true,
    footer: true,
    start: true,
    end: true
};

chrome.storage.local.get(defaultSettings, function(settings) {

    let css = "";

    if (settings.secondary) {
        css += `
            #secondary {
                display: none !important;
            }

            #primary {
                width: 100% !important;
                max-width: 100% !important;
            }

            #movie_player > div.ytp-fullscreen-grid > div.ytp-fullscreen-grid-main-content > div > * {
                display: none !important;
            }

#movie_player > div.ytp-ce-element.ytp-ce-channel,
#movie_player > div.ytp-ce-element.ytp-ce-video {
    display: none !important;
}
        `;
    }

    if (settings.below) {
        css += `
            #below {
                display: none !important;
            }
        `;
    }

    if (settings.sections) {
        css += `
            #sections > ytd-guide-section-renderer:nth-child(2) {
                display: none !important;
            }
        `;
    }

    if (settings.footer) {
        css += `
            #footer {
                display: none !important;
            }
        `;
    }

    if (settings.start) {
        css += `
            #logo {
                display: none !important;
            }

            #center {
                margin-left: auto !important;
                margin-right: auto !important;
            }
        `;
    }

    if (settings.end) {
        css += `
            #end {
                display: none !important;
            }
        `;
    }

    const style = document.createElement("style");

    style.textContent = css;

    document.documentElement.appendChild(style);

});